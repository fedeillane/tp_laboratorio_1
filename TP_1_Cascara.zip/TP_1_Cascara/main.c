#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{

    int opcion=0, primerOperando=0, segundoOperando=0, resultado=0, flag = 0;

    do{
        system("cls");

        // Tomo la opcion de la funcion menu
        opcion = menu(primerOperando, segundoOperando);

        // Valido en la primera vuelta solamente que se hayan tomado los operando
        while(opcion != 1 && flag == 0){
            printf("Error! Antes de realizar alguna operacion deberia ingresar el primer operando.");
            primerOperando = ingresoOperando(1);
            segundoOperando = ingresoOperando(2);
            flag = 1;
        }

        switch(opcion)
        {
            case 1:
                primerOperando = ingresoOperando(1);
                break;
            case 2:
                segundoOperando = ingresoOperando(2);
                break;
            case 3:
                resultado = suma(primerOperando, segundoOperando);
                mostrarResultado(resultado, 's');
                break;
            case 4:
                resultado = resta(primerOperando, segundoOperando);
                mostrarResultado(resultado, 'r');
                break;
            case 5:
                while(segundoOperando == 0){
                    printf("Error! El divisor no puede ser cero.");
                    segundoOperando = ingresoOperando(2);
                }

                resultado = division(primerOperando, segundoOperando);
                mostrarResultado(resultado, 'd');
                break;
            case 6:
                resultado = multiplicacion(primerOperando, segundoOperando);
                mostrarResultado(resultado, 'm');
                break;
            case 7:
                while(primerOperando <= 0){
                    printf("Error! No se puede sacar factoreal de un cero o numeros negativos.");
                    primerOperando = ingresoOperando(2);
                }
                resultado = factorial(primerOperando);
                mostrarResultado(resultado, 'f');
                break;
            case 8:
                calcularYMostrarOperaciones(primerOperando, segundoOperando);
                break;
            case 9:
                salir();
                break;
        }

    }while(opcion != 9);


    return 0;
}
