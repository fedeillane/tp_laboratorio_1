#include <stdio.h>
#include <stdlib.h>


/** Funcion que despliega el menu
 *
 * \param   int - nro1
 * \param   int - nro2
 * \return  int
 *
 */
int menu(int nro1, int nro2){

    int opcion = 0;

    printf("Hola y bienvenido a la calculador de Federico Illane\n\n");
    printf("1. Ingresar 1er operando (A=%d)\n", nro1);
    printf("2. Ingresar 2do operando (B=%d)\n", nro2);
    printf("3. Calcular la suma (A+B)\n");
    printf("4. Calcular la resta (A-B)\n");
    printf("5. Calcular la division (A/B)\n");
    printf("6. Calcular la multiplicacion (A*B)\n");
    printf("7. Calcular el factorial (A!)\n");
    printf("8. Calcular todas las operaciones\n");
    printf("9. Salir\n\n");

    do{
        printf("Seleccione la opcion deseada:");
        scanf("%d", &opcion);
    }while(opcion < 1 || opcion > 9);

    return opcion;
}

/** Funcion que suma los 2 operandos
 *
 * \param   int nro1
 * \param   int nro2
 * \return  int
 */
int suma(int nro1, int nro2){

    return nro1 + nro2;
}

/** Funcion que resta los 2 operandos
 *
 * \param   int nro1
 * \param   int nro2
 * \return  int
 */
int resta(int nro1, int nro2){

    return nro1 - nro2;
}

/** Funcion que divide los 2 operandos
 *
 * \param   int - nro1
 * \param   int - nro2
 * \return  int
 */
int division(int nro1, int nro2){

    return nro1 / nro2;                    /** REVISAR DIVISION */
}

/** Funcion que multiplica los 2 operandos
 *
 * \param   int - nro1
 * \param   int - nro2
 * \return  int
 */
int multiplicacion(int nro1, int nro2){

    return nro1 * nro2;
}

/** Funcion que saca el factorial del primer operando
 *
 * \param   int - nro1
 * \return  int
 */
int factorial(int nro1){

    int i;

    for(i=(nro1-1);i>0;i--){
        nro1 *= i;
    }

    return nro1;
}

/** Funcion que calcula todas las operaciones y su vez muestra todos los resultados.
 *
 * \param   int - nro1
 * \param   int - nro2
 * \return  void
 */
void calcularYMostrarOperaciones(int nro1, int nro2){

    int resultadoSuma = 0, resultadoResta = 0, resultadoDivision = 0, resultadoMultiplicacion  = 0, resultadoFactorial = 0;

        resultadoSuma = suma(nro1, nro2),
        resultadoResta = resta(nro1, nro2),
        resultadoDivision = division(nro1, nro2),
        resultadoMultiplicacion = multiplicacion(nro1, nro2),
        resultadoFactorial = factorial(nro1);

        mostrarResultado(resultadoSuma, 's');
        mostrarResultado(resultadoResta, 'r');
        mostrarResultado(resultadoDivision, 'd');
        mostrarResultado(resultadoMultiplicacion, 'm');
        mostrarResultado(resultadoFactorial, 'f');
}

/** Funcion que muestra los resultados de las distintas operaciones
 *
 * \param   int     - resultado
 * \param   char    - operacion
 * \return  void
 */
void mostrarResultado(int resultado, char operacion){

    switch(operacion){

        case 's':
            printf("El resultado de la suma es: %d\n", resultado);
            break;

        case 'r':
            printf("El resultado de la resta es: %d\n", resultado);
            break;

        case 'd':
            printf("El resultado de la division es: %d\n", resultado);
            break;

        case 'm':
            printf("El resultado de la multiplicacion es: %d\n", resultado);
            break;

        case 'f':
            printf("El resultado del factorial es: %d\n", resultado);
            break;

    }
}

/** Funcion que toma los operando para las operaciones
 *
 * \param   int - operando
 * \return  int
 */
int ingresoOperando(int operando){

    int numero;

    printf("Ingrese el %d� operando: ", operando);

    scanf("%d", &numero);

    return numero;
}

/** Funcion para salir del menu
 *
 * \param   void
 * \return  void
 */
void salir(void){

    printf("Adios!");
}

/** Funcion para validar numeros para la operacion de factoreo o de division.
 *
 * \param   int     - numeroAValidar
 * \param   char    - operacion
 * \return  bool
 */
int validarNumeros(int numeroAValidar, char operacion){

    if(numeroAValidar <= 0 && operacion == 'f'){
        printf("No se puede sacar el factorial de cero o de numeros negativos");
        return 1;
    }

    if(numeroAValidar == 0 && operacion == 'd'){
        printf("El divisor no puede ser cero");
        return 1;
    }

    return 0;
}

