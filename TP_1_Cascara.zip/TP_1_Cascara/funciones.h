#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED


/** Funcion que despliega el menu
 *
 * \param   int - nro1
 * \param   int - nro2
 * \return  int
 *
 */
int menu(int, int);


/** Funcion que suma los 2 operandos
 *
 * \param   int nro1
 * \param   int nro2
 * \return  int
 */
int suma(int, int);


/** Funcion que resta los 2 operandos
 *
 * \param   int nro1
 * \param   int nro2
 * \return  int
 */
int resta(int, int);


/** Funcion que divide los 2 operandos
 *
 * \param   int - nro1
 * \param   int - nro2
 * \return  int
 */
int division(int, int);


/** Funcion que multiplica los 2 operandos
 *
 * \param   int - nro1
 * \param   int - nro2
 * \return  int
 */
int multiplicacion(int, int);


/** Funcion que saca el factorial del primer operando
 *
 * \param   int - nro1
 * \return  int
 */
int factorial(int);


/** Funcion que calcula todas las operaciones y su vez muestra todos los resultados.
 *
 * \param   int - nro1
 * \param   int - nro2
 * \return  void
 */
void calcularYMostrarOperaciones(int, int);


/** Funcion que muestra los resultados de las distintas operaciones
 *
 * \param   int     - resultado
 * \param   char    - operacion
 * \return  void
 */
void mostrarResultado(int, char);


/** Funcion que toma los operando para las operaciones
 *
 * \param   int - operando
 * \return  int
 */
int ingresoOperando(int);


/** Funcion para salir del menu
 *
 * \param   void
 * \return  void
 */
void salir(void);


/** Funcion para validar numeros para la operacion de factoreo o de division.
 *
 * \param   int     - numeroAValidar
 * \param   char    - operacion
 * \return  bool
 */
int validarNumeros(int, char);


#endif // FUNCIONES_H_INCLUDED
